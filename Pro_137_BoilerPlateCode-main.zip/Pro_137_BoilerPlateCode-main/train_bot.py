#Text Data Preprocessing Lib


# function for appending stem words



    
        # Add all words of patterns to list
        
        # Add all tags to the classes list
         

#Create word corpus for chatbot

